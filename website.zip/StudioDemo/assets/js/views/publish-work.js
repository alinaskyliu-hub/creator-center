(() => {
  const form = document.querySelector('#publish-form');
  const panels = [...document.querySelectorAll('[data-step]')];
  const steps = ['basic', 'rights', 'video'];
  const buttons = [...document.querySelectorAll('[data-step-button]')];
  const toast = document.querySelector('#toast');
  let active = 0;
  let toastTimer;

  function message(value) {
    toast.textContent = value;
    toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toast.hidden = true; }, 4200);
  }
  function showStep(index) {
    active = Math.max(0, Math.min(index, steps.length - 1));
    panels.forEach((panel, position) => { panel.hidden = position !== active; });
    buttons.forEach((button, position) => {
      button.classList.toggle('active', position === active);
      button.classList.toggle('done', position < active);
      button.setAttribute('aria-current', position === active ? 'step' : 'false');
    });
    document.querySelector('#step-count').textContent = `第 ${active + 1} 步，共 3 步`;
    document.querySelector('#previous-step').hidden = active === 0;
    document.querySelector('#next-step').hidden = active === 2;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  function validFields(panel) {
    const required = [...panel.querySelectorAll('[required]')].filter(el => !el.closest('.optional-group[hidden]'));
    for (const input of required) {
      input.classList.remove('invalid');
      if (!input.checkValidity()) {
        input.classList.add('invalid');
        if (panel.dataset.step === 'rights') document.querySelector('.qualification-warning').hidden = false;
        if (input.name === 'coverFiles') document.querySelector('[data-cover-trigger]').focus();
        else input.focus();
        message('请先填写或上传必填项。');
        return false;
      }
      if (input.type === 'file' && input.files[0]) {
        const maximum = panel.dataset.step === 'basic' ? 5 : 20;
        if (input.files.length > 20 || [...input.files].some(file => file.size > maximum * 1024 * 1024)) {
          input.classList.add('invalid'); input.focus();
          message(`每项最多 20 个文件，单份不能超过 ${maximum} MB。`); return false;
        }
        if (panel.dataset.step === 'rights' && [...input.files].some(file => !/\.(jpe?g|png|pdf)$/i.test(file.name) || !['image/jpeg', 'image/png', 'application/pdf'].includes(file.type))) {
          input.classList.add('invalid'); input.focus();
          message('资质文件仅支持 JPG、JPEG、PNG 或 PDF。'); return false;
        }
      }
    }
    if (panel.dataset.step === 'basic') {
      if (!panel.querySelector('[name="audience"]:checked')) { message('请选择分类。'); return false; }
      if (!panel.querySelector('[name="region"]:checked')) { message('请选择地区。'); return false; }
      if (!panel.querySelector('[name="tags"]:checked')) { message('请至少选择一个标签。'); return false; }
      if (form.elements.paidStatus.value === '付费' && !form.elements.paidFromEpisode.value) {
        form.elements.paidFromEpisode.focus(); message('请填写开始付费集。'); return false;
      }
    }
    if (panel.dataset.step === 'rights') {
      for (const role of ['maker', 'coProducer']) {
        const group = document.querySelector(`[data-optional-group="${role}"]`);
        if (!group.hidden && !group.querySelector('.company-card')) {
          group.querySelector('[data-add-company]').focus();
          message(role === 'maker' ? '请添加制作方并上传资质文件。' : '请添加联合出品方并上传资质文件。');
          return false;
        }
      }
    }
    if (panel.dataset.step === 'rights') document.querySelector('.qualification-warning').hidden = true;
    return true;
  }
  function selectedMethod() { return form.elements.uploadMethod.value; }
  function validVideo() {
    if (form.elements.finishStatus.value === '未成片') return true;
    const method = selectedMethod();
    if (method === 'local') {
      if (!form.elements.videoFiles.files.length) { message('请选择正片视频。'); form.elements.videoFiles.focus(); return false; }
      return true;
    }
    const input = form.elements[method + 'Url'];
    let url;
    try { url = new URL(input.value.trim()); } catch { url = null; }
    if (!url || url.protocol !== 'https:' || !url.hostname) {
      input.classList.add('invalid'); input.focus(); message('请填写完整的 HTTPS 分享地址。'); return false;
    }
    if (method === 'baidu' && url.hostname !== 'pan.baidu.com') { message('请填写百度网盘分享地址。'); input.focus(); return false; }
    if (method === 'baidu' && !form.elements.baiduCode.value.trim()) {
      form.elements.baiduCode.classList.add('invalid'); form.elements.baiduCode.focus();
      message('请填写百度网盘提取码。'); return false;
    }
    if (method === 'google' && !['drive.google.com', 'docs.google.com'].includes(url.hostname)) { message('请填写 Google 网盘分享地址。'); input.focus(); return false; }
    return true;
  }
  document.querySelector('#previous-step').addEventListener('click', () => showStep(active - 1));
  document.querySelector('#next-step').addEventListener('click', () => {
    if (active === 0 && !validFields(panels[0])) return;
    if (active === 1 && !validFields(panels[1])) return;
    showStep(active + 1);
  });
  buttons.forEach((button, index) => button.addEventListener('click', () => showStep(index)));
  document.querySelectorAll('[data-optional-toggle]').forEach(input => input.addEventListener('change', () => {
    const group = document.querySelector(`[data-optional-group="${input.dataset.optionalToggle}"]`);
    group.hidden = form.elements[input.name].value !== '有';
    group.querySelectorAll('input').forEach(field => { field.required = !group.hidden; });
  }));
  const companyTemplates = new Map();
  for (const role of ['producer', 'maker', 'coProducer']) {
    const list = document.querySelector(`[data-company-list="${role}"]`);
    companyTemplates.set(role, list.firstElementChild.cloneNode(true));
    if (role !== 'producer') list.replaceChildren();
  }
  document.querySelectorAll('[data-add-company]').forEach(button => button.addEventListener('click', () => {
    const role = button.dataset.addCompany;
    const list = document.querySelector(`[data-company-list="${role}"]`);
    const card = companyTemplates.get(role).cloneNode(true);
    card.querySelectorAll('input').forEach(input => {
      input.value = '';
      input.classList.remove('invalid');
      if (role !== 'producer') input.required = true;
    });
    card.querySelectorAll('output').forEach(output => { output.textContent = '0/20'; });
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'remove-company';
    remove.textContent = '删除此单位';
    remove.addEventListener('click', () => card.remove());
    card.append(remove);
    list.append(card);
  }));
  form.addEventListener('input', event => {
    const wrap = event.target.closest('.company-name-input');
    if (wrap) wrap.querySelector('output').textContent = `${event.target.value.length}/20`;
  });
  document.querySelectorAll('[name="uploadMethod"]').forEach(input => input.addEventListener('change', () => {
    document.querySelectorAll('[data-upload-detail]').forEach(detail => { detail.hidden = detail.dataset.uploadDetail !== selectedMethod(); });
  }));
  const baiduCode = form.elements.baiduCode;
  function syncBaiduCode() {
    const hasCode = Boolean(baiduCode.value.trim());
    document.querySelector('#extract-baidu').disabled = !hasCode || !form.elements.baiduUrl.value.trim();
    document.querySelector('#baidu-code-error').hidden = hasCode;
  }
  baiduCode.addEventListener('input', syncBaiduCode);
  form.elements.baiduUrl.addEventListener('input', () => {
    try {
      const code = new URL(form.elements.baiduUrl.value.trim()).searchParams.get('pwd');
      if (code && !baiduCode.value) baiduCode.value = code;
    } catch (_) {}
    syncBaiduCode();
  });
  document.querySelector('#extract-baidu').addEventListener('click', () => {
    if (!validVideo()) return;
    message('本地原型暂不能连接百度网盘提取文件；链接和提取码已保存在表单中。');
  });
  syncBaiduCode();
  const coverInput = form.elements.coverFiles;
  document.querySelector('[data-cover-trigger]').addEventListener('click', () => coverInput.click());
  coverInput.addEventListener('change', () => {
    const selected = document.querySelector('[data-cover-selected]');
    selected.replaceChildren();
    [...coverInput.files].forEach(file => {
      const item = document.createElement('span');
      item.textContent = file.name;
      item.title = file.name;
      selected.append(item);
    });
  });
  form.querySelectorAll('[data-stepper]').forEach(button => button.addEventListener('click', () => {
    const input = form.elements[button.dataset.stepper];
    if (input.disabled) return;
    const minimum = Number(input.min) || 0;
    const next = (Number(input.value) || 0) + Number(button.dataset.delta);
    input.value = String(Math.max(minimum, next));
    input.dispatchEvent(new Event('input', { bubbles: true }));
  }));
  form.querySelectorAll('[data-counter-for]').forEach(counter => {
    const input = form.elements[counter.dataset.counterFor];
    const update = () => { counter.textContent = `${input.value.length}/${input.maxLength}`; };
    input.addEventListener('input', update);
    update();
  });
  let producerIndex = 1;
  document.querySelectorAll('[data-add-row]').forEach(button => button.addEventListener('click', () => {
    const group = button.dataset.addRow;
    const container = document.querySelector(`[data-repeatable="${group}"]`);
    const item = container.firstElementChild.cloneNode(true);
    item.querySelectorAll('input').forEach(input => {
      if (input.type === 'radio') input.checked = input.value === '男';
      else input.value = '';
      input.classList.remove('invalid');
    });
    if (group === 'producer') {
      producerIndex++;
      item.querySelectorAll('input[type="radio"]').forEach(input => { input.name = `producerGender${producerIndex}`; });
    }
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'remove-row';
    remove.textContent = '删除';
    remove.addEventListener('click', () => item.remove());
    item.append(remove);
    container.append(item);
  }));
  function syncPaidStatus() {
    const paid = form.elements.paidStatus.value === '付费';
    form.querySelectorAll('[data-paid-only]').forEach(field => {
      field.hidden = !paid;
      field.querySelectorAll('input,button').forEach(control => { control.disabled = !paid; });
    });
  }
  document.querySelectorAll('[name="paidStatus"]').forEach(input => input.addEventListener('change', syncPaidStatus));
  syncPaidStatus();
  form.querySelectorAll('input,select,textarea').forEach(input => input.addEventListener('input', () => input.classList.remove('invalid')));

  const databaseName = 'studio-publish-projects-v1';
  const fallbackKey = 'studio-publish-draft-v1';
  function openDatabase() {
    return new Promise((resolve, reject) => {
      if (!('indexedDB' in window)) { reject(new Error('浏览器不支持本地数据库')); return; }
      const request = indexedDB.open(databaseName, 1);
      request.onupgradeneeded = () => { request.result.createObjectStore('records'); };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  async function writeDatabase(record) {
    const db = await openDatabase();
    try {
      await new Promise((resolve, reject) => {
        const tx = db.transaction('records', 'readwrite');
        tx.oncomplete = resolve;
        tx.onerror = () => reject(tx.error);
        tx.objectStore('records').put(record, 'current');
      });
    } finally { db.close(); }
  }
  async function readDatabase() {
    const db = await openDatabase();
    try {
      return await new Promise((resolve, reject) => {
        const request = db.transaction('records', 'readonly').objectStore('records').get('current');
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
      });
    } finally { db.close(); }
  }
  function collectRecord(status) {
    return {
      status,
      savedAt: new Date().toISOString(),
      step: active,
      counts: Object.fromEntries(['director', 'cast', 'producer'].map(role => [role, document.querySelectorAll(`[data-repeatable="${role}"] .repeat-item`).length])),
      companyCounts: Object.fromEntries(['producer', 'maker', 'coProducer'].map(role => [role, document.querySelectorAll(`[data-company-list="${role}"] .company-card`).length])),
      controls: [...form.querySelectorAll('input[name],select[name],textarea[name]')].map(input => ({
        name: input.name,
        type: input.type,
        value: input.type === 'file' ? '' : input.value,
        checked: input.checked,
        files: input.type === 'file' ? [...input.files] : []
      }))
    };
  }
  async function saveProject(status) {
    const record = collectRecord(status);
    try {
      await writeDatabase(record);
      try { localStorage.removeItem(fallbackKey); } catch (_) {}
      document.querySelector('#project-status').textContent = status === 'draft' ? '草稿已保存（本机）' : '项目已提交（本地演示）';
      message(status === 'draft' ? '项目已保存到本机浏览器，再次打开“发布作品”可继续编辑。' : '项目已记录为本地已提交；本原型未连接爱奇艺后台。');
      return true;
    } catch (_) {
      try {
        const textOnly = { ...record, controls: record.controls.map(control => ({ ...control, files: [] })) };
        localStorage.setItem(fallbackKey, JSON.stringify(textOnly));
        document.querySelector('#project-status').textContent = status === 'draft' ? '文字草稿已保存' : '本地已提交（文件未保存）';
        message('文字已保存到本机浏览器；文件因浏览器存储限制需重新选择。');
        return true;
      } catch (_) {
        message('保存失败：当前浏览器未开放本地存储，请检查浏览器设置。');
        return false;
      }
    }
  }
  function restoreRecord(record) {
    for (const [role, count] of Object.entries(record.counts || {})) {
      while (document.querySelectorAll(`[data-repeatable="${role}"] .repeat-item`).length < count) {
        document.querySelector(`[data-add-row="${role}"]`).click();
      }
    }
    for (const [role, count] of Object.entries(record.companyCounts || {})) {
      if (role !== 'producer') {
        const names = role === 'maker'
          ? ['makerName[]', 'makerIpFiles[]', 'makerCopyrightFiles[]']
          : ['coProducerName[]', 'coProducerIpFiles[]', 'coProducerCopyrightFiles[]'];
        const hasSavedContent = (record.controls || []).some(control => names.includes(control.name) && (String(control.value || '').trim() || control.files?.length));
        if (!hasSavedContent) continue;
      }
      while (document.querySelectorAll(`[data-company-list="${role}"] .company-card`).length < count) {
        document.querySelector(`[data-add-company="${role}"]`).click();
      }
    }
    const saved = new Map();
    (record.controls || []).forEach(control => {
      if (!saved.has(control.name)) saved.set(control.name, []);
      saved.get(control.name).push(control);
    });
    let missingFiles = false;
    form.querySelectorAll('input[name],select[name],textarea[name]').forEach(input => {
      const entry = saved.get(input.name)?.shift();
      if (!entry) return;
      if (input.type === 'file') {
        if (entry.files?.length) {
          try {
            const transfer = new DataTransfer();
            entry.files.forEach(file => transfer.items.add(file));
            input.files = transfer.files;
          } catch (_) { missingFiles = true; }
        }
      } else if (input.type === 'checkbox' || input.type === 'radio') input.checked = entry.checked;
      else input.value = entry.value;
    });
    document.querySelectorAll('[data-optional-toggle]:checked').forEach(input => input.dispatchEvent(new Event('change')));
    document.querySelector('[name="uploadMethod"]:checked')?.dispatchEvent(new Event('change'));
    syncBaiduCode();
    syncPaidStatus();
    coverInput.dispatchEvent(new Event('change'));
    form.querySelectorAll('[data-counter-for]').forEach(counter => {
      const input = form.elements[counter.dataset.counterFor];
      counter.textContent = `${input.value.length}/${input.maxLength}`;
    });
    form.querySelectorAll('.company-name-input').forEach(wrap => { wrap.querySelector('output').textContent = `${wrap.querySelector('input').value.length}/20`; });
    showStep(Number.isInteger(record.step) ? record.step : 0);
    document.querySelector('#project-status').textContent = record.status === 'submitted' ? '项目已提交（本地演示）' : '已恢复上次草稿';
    message(missingFiles ? '已恢复文字内容，部分文件需重新选择。' : '已恢复上次保存的项目。');
  }
  document.querySelector('#save-project').addEventListener('click', () => { void saveProject('draft'); });
  document.querySelector('#submit-project').addEventListener('click', async () => {
    for (let index = 0; index < 2; index++) {
      showStep(index);
      if (!validFields(panels[index])) return;
    }
    showStep(2);
    if (!validVideo()) return;
    await saveProject('submitted');
  });
  showStep(0);
  (async () => {
    let record, fallback;
    try { record = await readDatabase(); } catch (_) {}
    try { fallback = JSON.parse(localStorage.getItem(fallbackKey) || 'null'); } catch (_) {}
    if (fallback && (!record || fallback.savedAt > record.savedAt)) record = fallback;
    if (record) restoreRecord(record);
  })();
})();
