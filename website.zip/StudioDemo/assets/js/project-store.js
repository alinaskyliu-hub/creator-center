/* Shared local project storage; existing v1 files remain readable. */
(function (root) {
  const backupKey = 'studio-projects-v2';
  const legacyKey = 'studio-publish-draft-v1';
  const legacyId = 'project-legacy-current';
  function open() {
    return new Promise((resolve, reject) => {
      const request = root.indexedDB.open('studio-publish-projects-v1', 1);
      request.onupgradeneeded = () => request.result.createObjectStore('records');
      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result);
    });
  }
  async function database(mode, action) {
    const db = await open();
    try {
      return await new Promise((resolve, reject) => {
        const tx = db.transaction('records', mode);
        const request = action(tx.objectStore('records'));
        tx.oncomplete = () => resolve(request.result);
        tx.onerror = tx.onabort = () => reject(tx.error);
      });
    } finally { db.close(); }
  }
  function backups() { return JSON.parse(root.localStorage.getItem(backupKey) || '{}'); }
  function normalize(record, id) {
    return { ...record, id: record.id || id, createdAt: record.createdAt || record.savedAt, updatedAt: record.updatedAt || record.savedAt };
  }
  async function list() {
    let records = [], readable = false;
    try { records = await database('readonly', store => store.getAll()); readable = true; } catch (_) {}
    try {
      records.push(...Object.values(backups()));
      const legacy = JSON.parse(root.localStorage.getItem(legacyKey) || 'null');
      if (legacy) records.push(legacy);
      readable = true;
    } catch (_) {}
    if (!readable) throw new Error('无法读取本地项目');
    const merged = new Map();
    records.forEach(record => {
      const next = normalize(record, legacyId), old = merged.get(next.id);
      if (!old || next.updatedAt > old.updatedAt) merged.set(next.id, next);
    });
    return [...merged.values()].sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt)));
  }
  async function save(record) {
    const value = normalize(record, root.crypto.randomUUID());
    try {
      await database('readwrite', store => store.put(value, value.id));
      try { const copy = backups(); delete copy[value.id]; root.localStorage.setItem(backupKey, JSON.stringify(copy)); } catch (_) {}
      return value;
    } catch (_) {
      const copy = backups();
      const textOnly = { ...value, filesMissing: true, controls: value.controls.map(control => ({ ...control, files: [] })) };
      copy[value.id] = textOnly;
      root.localStorage.setItem(backupKey, JSON.stringify(copy));
      return textOnly;
    }
  }
  function value(record, name) {
    return record.controls?.find(control => control.name === name && (!['radio', 'checkbox'].includes(control.type) || control.checked))?.value || '';
  }
  function row(record) {
    return { id: record.id, local: true, title: value(record, 'title').trim() || '未命名项目', type: 'short', episodes: value(record, 'episodeCount'), freePaidStatus: value(record, 'paidStatus') === '免费' ? 'Free' : 'Paid', publicationStatus: record.status === 'submitted' ? 'Publishing' : 'Draft', updated: record.updatedAt, createdAt: record.createdAt, cover: record.controls?.find(c => c.name === 'coverFiles')?.files?.find(f => /^image\/(jpeg|png)$/.test(f.type)) };
  }
  root.StudioProjects = { list, save, get: async id => (await list()).find(record => record.id === id), row };
})(window);
