// Runs after the shared markup, before each page's translations and event wiring.
(() => {
  const { linked, href } = window.StudioAccount;
  if (linked) {
    document.querySelectorAll('link[data-unlinked-only]').forEach(link => { link.disabled = true; });
    const account = document.querySelector('.sidebar .main-site-account');
    if (account) {
      account.dataset.accountState = 'linked';
      account.title = '主站账号：已绑定';
      account.dataset.i18nTitle = 'mainSiteAccountLinked';
      const status = account.querySelector('.main-site-account-status');
      status.dataset.i18n = 'linkedStatus';
      status.textContent = '已绑定';
      const name = account.querySelector('.main-site-account-name');
      name.dataset.i18n = 'mainSiteAccountName';
      name.textContent = '用户00260922';
      account.querySelector('img').src = 'assets/images/main-site-linked-avatar.png';
    }
  }
  const publishAccount = document.querySelector('.sidebar .account');
  if (publishAccount) {
    publishAccount.querySelector('b').textContent = linked ? '● 已绑定' : '未绑定';
    publishAccount.querySelector('span').textContent = linked ? '用户00260922' : '主站账号';
  }
  document.querySelectorAll('a[href]').forEach(link => {
    const original = link.getAttribute('href');
    if (!original.startsWith('#')) link.setAttribute('href', href(original));
  });
})();
