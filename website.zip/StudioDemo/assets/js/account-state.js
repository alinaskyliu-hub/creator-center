// Default to linked; linked=0 explicitly selects the unlinked demo state.
(() => {
  const current = new URL(location.href);
  const linked = current.searchParams.get('linked') !== '0';
  const directory = new URL('.', current).href;
  function href(target, state = linked) {
    const url = new URL(target, current);
    if (new URL('.', url).href !== directory ||
        !/\/(index|content|analytics|account-setting|edit|edit2|publish-work)(?:-linked)?\.html$/.test(url.pathname)) return target;
    url.pathname = url.pathname.replace(/-linked\.html$/, '.html');
    if (state) url.searchParams.set('linked', '1');
    else url.searchParams.set('linked', '0');
    return url.pathname.split('/').pop() + url.search + url.hash;
  }
  window.StudioAccount = { linked, href };
  document.documentElement.dataset.accountState = linked ? 'linked' : 'unlinked';
})();
