// Preserve the root legacy entry while selecting the linked demo.
(() => {
  const target = new URL(location.href);
  target.pathname = target.pathname.replace(/content-linked\.html$/, 'content.html');
  target.searchParams.set('linked', '1');
  location.replace(target.href);
})();
