const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, '../js/project-store.js'), 'utf8');
function setup() {
  const data = new Map(); let seq = 0;
  const window = { crypto: { randomUUID: () => `id-${++seq}` }, localStorage: { getItem: k => data.get(k) || null, setItem: (k,v) => data.set(k,v) } };
  vm.runInNewContext(source, { window });
  return { store: window.StudioProjects, data, window };
}
const record = (title, time='2026-10-13T01:00:00Z') => ({ status:'draft', savedAt:time, updatedAt:time, createdAt:time, controls:[{name:'title',value:title},{name:'paidStatus',type:'radio',checked:true,value:'免费'}] });
test('multiple fallback drafts remain distinct; editing replaces same ID and preserves creation time', async () => {
  const {store} = setup();
  const a = await store.save(record('A')), b = await store.save(record('B'));
  assert.notEqual(a.id,b.id);
  const edited=await store.save({...a, updatedAt:'2026-10-14T01:00:00Z', controls:record('Edited').controls});
  assert.equal((await store.list()).length,2);
  assert.equal(edited.createdAt,a.createdAt);
  assert.equal(store.row(await store.get(a.id)).title,'Edited');
  assert.equal(await store.get('missing'),undefined);
});
test('legacy draft gets a stable ID, survives repeat reads, and is superseded by edits', async () => {
  const {store,data}=setup();data.set('studio-publish-draft-v1',JSON.stringify(record('Legacy')));
  const old=(await store.list())[0];assert.equal(old.id,(await store.list())[0].id);
  await store.save({...old,updatedAt:'2026-10-14T01:00:00Z',controls:record('New').controls});
  assert.equal((await store.list()).length,1);assert.equal(store.row((await store.list())[0]).title,'New');
});
test('fallback flags missing files; total storage failure rejects rather than reporting success',async()=>{
  const {store,window}=setup();const saved=await store.save({...record(''),controls:[{name:'coverFiles',files:[{type:'image/png'}]}]});
  assert.equal(saved.filesMissing,true);assert.equal(store.row(saved).title,'未命名项目');assert.equal(store.row(saved).type,'short');assert.equal(saved.controls[0].files.length,0);
  window.localStorage.setItem=()=>{throw Error('quota')};await assert.rejects(store.save(record('Fail')));
});
test('content row safely escapes user text and links to the same project with binding state',()=>{
  const content=fs.readFileSync(path.join(__dirname,'../js/views/content.js'),'utf8');
  const context=vm.createContext({URL,location:{href:'https://example.test/content.html?savedProject=p1'},window:{StudioAccount:{linked:false}},renderPublicationStatus:()=>'<span>草稿</span>'});
  vm.runInContext(content.slice(0,content.indexOf('const messages =')),context);
  const html=context.renderLocalProject({id:'p1',title:'<img src=x onerror=alert(1)>',episodes:'2',freePaidStatus:'Free',publicationStatus:'Draft',updated:'2026-10-13T01:00:00Z'});
  assert.ok(html.includes('&lt;img'));assert.ok(!html.includes('<img src=x'));assert.ok(html.includes('projectId=p1&amp;linked=0'));assert.ok(html.includes('project-saved'));assert.ok(!html.includes('data-toggle-publication'));
});
