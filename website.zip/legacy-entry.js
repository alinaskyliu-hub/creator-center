(() => {
  const current = new URL(window.location.href);
  const name = current.pathname.split('/').pop() || 'index.html';
  const target = new URL('StudioDemo/' + name, current);
  target.search = current.search;
  target.hash = current.hash;
  window.location.replace(target.href);
})();
