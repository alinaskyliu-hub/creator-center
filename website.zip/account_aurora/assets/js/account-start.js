window.AccountApp.start();
